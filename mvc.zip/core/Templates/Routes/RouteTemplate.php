
/*auth routes*/
Route::authenticate();
